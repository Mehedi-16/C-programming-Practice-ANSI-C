#include <stdio.h>

const char *day_name(int n) {
    static const char *days[] = {
        "Invalid", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
    };

    if (n >= 1 && n <= 7) {
        return days[n];
    } else {
        return days[0]; // Invalid day
    }
}

int main() {
    int n;

    printf("Enter a number (1-7) to get the corresponding day: ");
    scanf("%d", &n);

    const char *day = day_name(n);

    printf("Day: %s\n", day);

    return 0;
}
