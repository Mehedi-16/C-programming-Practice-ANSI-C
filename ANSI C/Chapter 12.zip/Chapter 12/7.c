#include <stdio.h>
int binary_search(const int *arr, int size, int target) {
    int left = 0;
    int right = size - 1;

    while (left <= right) {
        int middle = left + (right - left) / 2;
        if (arr[middle] == target) {
            return middle; 
        } else if (arr[middle] < target) {
            left = middle + 1; 
        } else {
            right = middle - 1; 
        }
    }

    return -1;
}

int main() {
    int sorted_nums[] = {1, 4, 7, 9, 12, 15, 18, 21, 24, 27};
    int size = sizeof(sorted_nums) / sizeof(sorted_nums[0]);

    int target;
    printf("Enter the number to search for: ");
    scanf("%d", &target);

    int index = binary_search(sorted_nums, size, target);

    if (index != -1) {
        printf("%d found at index %d\n", target, index);
    } else {
        printf("%d not found in the list\n", target);
    }

    return 0;
}
