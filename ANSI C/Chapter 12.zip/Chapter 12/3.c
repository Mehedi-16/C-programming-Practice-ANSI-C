#include<stdio.h>
void insertIntoSortedArray(int arr[], int n, int value) {
    int i = n - 1;

    while (i >= 0 && arr[i] > value) {
        arr[i + 1] = arr[i];
        i--;
    }

    arr[i + 1] = value;
}

int main() {
    int n;

    printf("Enter the size of the sorted array: ");
    scanf("%d", &n);

    int sortedArray[n];

    printf("Enter %d sorted integers:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &sortedArray[i]);
    }

    int value;
    printf("Enter the integer value to insert: ");
    scanf("%d", &value);

    insertIntoSortedArray(sortedArray, n, value);

    printf("Array after insertion:\n");
    for (int i = 0; i <= n; i++) {
        printf("%d ", sortedArray[i]);
    }

    return 0;
}
