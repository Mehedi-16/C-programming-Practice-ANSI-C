#include <stdio.h>
#include <string.h>

void insertSubstring(char *dest, const char *src, int pos) 
{
    memmove(dest + pos + strlen(src), dest + pos, strlen(dest) - pos + 1);
    strncpy(dest + pos, src, strlen(src));
}

int main() {
    char mainStr[100] = "Hello, there!";
    char subStr[] = "world";

    insertSubstring(mainStr, subStr, 7);

    printf("Modified string: %s\n", mainStr);

    return 0;
}
