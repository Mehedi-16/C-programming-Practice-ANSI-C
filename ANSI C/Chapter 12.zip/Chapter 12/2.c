#include<stdio.h>
#include<math.h>

int main() 
{
    double a, b, c;
    double discriminant, root1, root2;

    printf("Enter coefficients a, b, and c: ");
    scanf("%lf %lf %lf", &a, &b, &c);

    discriminant = b * b - 4 * a * c;
    double *pRoot1 = &root1;
    double *pRoot2 = &root2;

    if (discriminant > 0) {
        *pRoot1 = (-b + sqrt(discriminant)) / (2 * a);
        *pRoot2 = (-b - sqrt(discriminant)) / (2 * a);
        printf("Roots are real and different.\n");
        printf("Root 1 = %.2lf\n", *pRoot1);
        printf("Root 2 = %.2lf\n", *pRoot2);
    } else if (discriminant == 0) {
        *pRoot1 = *pRoot2 = -b / (2 * a);
        printf("Roots are real and same.\n");
        printf("Root 1 = Root 2 = %.2lf\n", *pRoot1);
    } else {
        double realPart = -b / (2 * a);
        double imaginaryPart = sqrt(-discriminant) / (2 * a);
        *pRoot1 = realPart;
        *pRoot2 = imaginaryPart;
        printf("Roots are complex and different.\n");
        printf("Root 1 = %.2lf + %.2lfi\n", *pRoot1, *pRoot2);
        printf("Root 2 = %.2lf - %.2lfi\n", *pRoot1, -*pRoot2);
    }

    return 0;
}
