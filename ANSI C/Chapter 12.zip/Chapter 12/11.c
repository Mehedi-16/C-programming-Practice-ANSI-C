#include <stdio.h>
int main() {
    int numbers[] = {10, 20, 30, 40, 50};
    int *ptr = numbers;
printf("Original array:\n");

    for (int i = 0; i < 5; i++) {
        printf("Element %d: %d\n", i, *ptr);
        ptr++;
    }
    return 0;
}
