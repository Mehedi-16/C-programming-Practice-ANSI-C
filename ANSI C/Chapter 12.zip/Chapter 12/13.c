#include <stdio.h>
#include <string.h>
struct Student {
    int rollNumber;
    char name[50];
    int age;
};

int main() {
    struct Student student1;
    struct Student *ptrStudent = &student1;

    
    ptrStudent->rollNumber = 101;
    strcpy(ptrStudent->name, "Mehedi");
    ptrStudent->age = 20;

    printf("Initialized Student:\n");
    printf("Name: %s\n", ptrStudent->name);
    printf("Roll Number: %d\n", ptrStudent->rollNumber);
    printf("Age: %d\n", ptrStudent->age);

    return 0;
}
