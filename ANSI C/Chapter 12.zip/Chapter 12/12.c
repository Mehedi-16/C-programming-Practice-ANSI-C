#include <stdio.h>

int main() {
    int num1 = 10, num2 = 20, num3 = 30;

    int *ptrArray[] = {&num1, &num2, &num3};
    int numPointers = sizeof(ptrArray) / sizeof(ptrArray[0]);

    printf("Array of Pointers:\n");

    for (int i = 0; i < numPointers; i++) {
        printf("Pointer %d - Address: %p, Value: %d\n", i, ptrArray[i], *ptrArray[i]);
    }

    return 0;
}
