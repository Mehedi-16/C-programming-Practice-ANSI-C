#include <stdio.h>

struct date {
    int day;
    int month;
    int year;
};
int isLeapYear(int year) {
    if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
        return 1;
    else
        return 0;
}
int getDaysInMonth(int month, int year) {
    int daysInMonth[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (month == 2 && isLeapYear(year))
        return 29;
    else
        return daysInMonth[month];
}
struct date incrementDate(struct date currentDate) {
    int daysInMonth = getDaysInMonth(currentDate.month, currentDate.year);
    
    if (currentDate.day == daysInMonth) {
        currentDate.day = 1;
        if (currentDate.month == 12) {
            currentDate.month = 1;
            currentDate.year++;
        } else {
            currentDate.month++;
        }
    } else {
        currentDate.day++;
    }
    
    return currentDate;
}

int main() {
    struct date currentDate;
    printf("Enter the date (day month year): ");
    scanf("%d %d %d", &currentDate.day, &currentDate.month, &currentDate.year);
    struct date newDate = incrementDate(currentDate);

    printf("New date: %d %d %d\n", newDate.day, newDate.month, newDate.year);

    return 0;
}
