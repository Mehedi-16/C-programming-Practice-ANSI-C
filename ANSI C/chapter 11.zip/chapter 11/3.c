#include <stdio.h>
struct Time {
    int hour;
    int minute;
    int second;
};
struct Time update(struct Time time_data)
 {
    time_data.second++;

    if (time_data.second == 60) {
        time_data.second = 0;
        time_data.minute++;

        if (time_data.minute == 60) {
            time_data.minute = 0;
            time_data.hour++;
            if (time_data.hour == 24) {
                time_data.hour = 0;
            }
        }
    }

    return time_data;
}

int main() {
    struct Time time_data = {23, 59, 59};
    struct Time updated_time = update(time_data);
    printf("Updated time: %02d:%02d:%02d\n", updated_time.hour, updated_time.minute, updated_time.second);
    
    return 0;
}
