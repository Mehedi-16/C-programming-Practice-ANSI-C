#include <stdio.h>
struct date {
    int day;
    int month;
    int year;
};
struct student_record 
{
    char name[100];
    struct date dob;
    int total_marks;
};

int main() {
    struct student_record student;

    printf("Enter student name: ");
    scanf("%[^\n]", student.name);

    printf("Enter date of birth (DD MM YYYY): ");
    scanf("%d %d %d", &student.dob.day, &student.dob.month, &student.dob.year);

    printf("Enter total marks obtained: ");
    scanf("%d", &student.total_marks);

    printf("\nStudent Record:\n");
    printf("Name: %s\n", student.name);
    printf("Date of Birth: %d-%d-%d\n", student.dob.day, student.dob.month, student.dob.year);
    printf("Total Marks Obtained: %d\n", student.total_marks);
}
