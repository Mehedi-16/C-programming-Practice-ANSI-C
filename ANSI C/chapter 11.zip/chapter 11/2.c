#include <stdio.h>
struct me_struct 
{
    int hour;
    int minute;
    int second;
};
void input_time(struct me_struct *time) {
    printf("Enter hour: ");
    scanf("%d", &time->hour);

    printf("Enter minute: ");
    scanf("%d", &time->minute);

    printf("Enter second: ");
    scanf("%d", &time->second);
}
void display_time(struct me_struct time) {
    printf("Time: %02d:%02d:%02d\n", time.hour, time.minute, time.second);
}

int main() 
{
    struct me_struct my_time;
    input_time(&my_time);
    display_time(my_time);

    return 0;
}
