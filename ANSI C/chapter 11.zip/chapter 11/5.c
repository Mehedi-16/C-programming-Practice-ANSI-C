#include <stdio.h>

struct date {
    int day;
    int month;
    int year;
};
int isLeapYear(int year) 
{
    if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
        return 1;
    else
        return 0;
}

int getDaysInMonth(int month, int year) {
    int daysInMonth[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (month == 2 && isLeapYear(year))
        return 29;
    else
        return daysInMonth[month];
}
struct date readDateFromLongInteger(long dateValue) {
    struct date currentDate;
    
    currentDate.day = dateValue % 100;
    dateValue /= 100;
    
    currentDate.month = dateValue % 100;
    currentDate.year = dateValue / 100;

    return currentDate;
}
struct date incrementDate(struct date currentDate) {
    int daysInMonth = getDaysInMonth(currentDate.month, currentDate.year);
    
    if (currentDate.day == daysInMonth) {
        currentDate.day = 1;
        if (currentDate.month == 12) {
            currentDate.month = 1;
            currentDate.year++;
        } else {
            currentDate.month++;
        }
    } else {
        currentDate.day++;
    }
    
    return currentDate;
}

int main() {
    long dateValue;

    
    printf("Enter the date in the form of a long integer 1945-08-15 for August 15, 1945): ");
    scanf("%ld", &dateValue);
    struct date currentDate = readDateFromLongInteger(dateValue);
    struct date newDate = incrementDate(currentDate);
    printf("New date: %d-%d-%d\n", newDate.day, newDate.month, newDate.year);

    return 0;
}
