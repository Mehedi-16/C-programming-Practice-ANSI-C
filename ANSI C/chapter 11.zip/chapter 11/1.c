#include <stdio.h>
struct me_struct 
{
    int hour;
    int minute;
    int second;
};

int main() {
    struct me_struct my_time;
    my_time.hour = 12;
    my_time.minute = 34;
    my_time.second = 56;
    printf("Time: %02d:%02d:%02d\n", my_time.hour, my_time.minute, my_time.second);

    return 0;
}
