#include <stdio.h>

#define MAX_CITIES 5

struct census {
    char city[100];
    long int population;
    float literacy;
};

int main() {
    struct census cities[MAX_CITIES];
    int num_cities;

    printf("Enter the number of cities (up to %d): ", MAX_CITIES);
    scanf("%d", &num_cities);

    if (num_cities > MAX_CITIES) {
        printf("Number of cities exceeds the maximum limit.\n");
        return 1;
    }
    for (int i = 0; i < num_cities; i++) {
        printf("Enter the name of city %d: ", i + 1);
        scanf(" %[^\n]", cities[i].city);

        printf("Enter the population of city %d: ", i + 1);
        scanf("%ld", &cities[i].population);

        printf("Enter the literacy level of city %d: ", i + 1);
        scanf("%f", &cities[i].literacy);
    }
    printf("\nCity Data:\n");
    for (int i = 0; i < num_cities; i++) {
        printf("City: %s\n", cities[i].city);
        printf("Population: %ld\n", cities[i].population);
        printf("Literacy Level: %.2f\n", cities[i].literacy);
        printf("\n");
    }

    return 0;
}
