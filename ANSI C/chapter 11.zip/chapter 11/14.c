#include <stdio.h>

struct example_struct {
    int x;
    char c;
    double d;
};

union example_union {
    int x;
    char c;
    double d;
};

int main() {
    struct example_struct example_struct_var;
    union example_union example_union_var;

    printf("Size of 'example_struct' structure: %zu bytes\n", sizeof(example_struct_var));
    printf("Size of 'example_union' union: %zu bytes\n", sizeof(example_union_var));

    return 0;
}
