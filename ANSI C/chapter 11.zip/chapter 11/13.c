#include <stdio.h>

struct example_struct {
    int x;
    char c;
    double d;
};

int main() {
    struct example_struct example;

    printf("Size of the 'example_struct' structure: %zu bytes\n", sizeof(example));

    return 0;
}
