#include <stdio.h>
#include <string.h>

#define MAX_HOTELS 10

struct hotel {
    char name[100];
    char address[200];
    int grade;
    float average_room_charge;
    int num_rooms;
};

void print_hotels_by_grade(struct hotel hotels[], int num_hotels, int grade) {
    printf("Hotels of Grade %d in order of charges:\n", grade);
    int found = 0;

    for (int i = 0; i < num_hotels; i++) {
        if (hotels[i].grade == grade) {
            found = 1;
            printf("%s: $%.2f\n", hotels[i].name, hotels[i].average_room_charge);
        }
    }

    if (!found) {
        printf("No hotels found with Grade %d.\n", grade);
    }
}

void print_hotels_by_charge(struct hotel hotels[], int num_hotels, float max_charge) {
    printf("Hotels with Room Charges less than $%.2f:\n", max_charge);
    int found = 0;

    for (int i = 0; i < num_hotels; i++) {
        if (hotels[i].average_room_charge < max_charge) {
            found = 1;
            printf("%s: $%.2f\n", hotels[i].name, hotels[i].average_room_charge);
        }
    }

    if (!found) {
        printf("No hotels found with Room Charges less than $%.2f.\n", max_charge);
    }
}
int main() {
    struct hotel hotels[MAX_HOTELS];
    int num_hotels = 3; 
    int grade;
    float max_charge;

    printf("Enter the grade to filter hotels: ");
    scanf("%d", &grade);

    print_hotels_by_grade(hotels, num_hotels, grade);

    printf("Enter the maximum room charge to filter hotels: ");
    scanf("%f", &max_charge);

    print_hotels_by_charge(hotels, num_hotels, max_charge);

    return 0;
}
