#include <stdio.h>
#include <string.h>

struct cricket {
    char player_name[100];
    char team_name[100];
    int runs_scored;
    int matches_played;
};

int main() {
    struct cricket player[50];
    int num_players;

    printf("Enter the number of players (up to 50): ");
    scanf("%d", &num_players);

    if (num_players > 50) {
        printf("Number of players exceeds the maximum limit.\n");
        return 1;
    }

    for (int i = 0; i < num_players; i++) {
        printf("\nEnter the details for Player %d:\n", i + 1);

        printf("Player Name: ");
        scanf(" %[^\n]", player[i].player_name);

        printf("Team Name: ");
        scanf(" %[^\n]", player[i].team_name);

        printf("Runs Scored: ");
        scanf("%d", &player[i].runs_scored);

        printf("Matches Played: ");
        scanf("%d", &player[i].matches_played);
    }
    printf("\nTeam-wise List with Bang Average:\n");

    for (int i = 0; i < num_players; i++) {
        printf("Team: %s\n", player[i].team_name);
        printf("Player Name: %s\n", player[i].player_name);
        float bang_average = (float)player[i].runs_scored / player[i].matches_played;
        printf("Bang Average: %.2f\n\n", bang_average);
    }

    return 0;
}
