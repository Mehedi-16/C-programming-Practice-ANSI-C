#include <stdio.h>

struct Date {
    int day;
    int month;
    int year;
};

int isLeapYear(int year) {
    if (year % 400 == 0)
        return 1;
    if (year % 100 == 0)
        return 0;
    if (year % 4 == 0)
        return 1;
    return 0;
}

int getDaysInMonth(int month, int year) {
    int daysInMonth[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (month == 2 && isLeapYear(year))
        return 29;
    return daysInMonth[month];
}

struct Date nextdate(struct Date presentDate, int daysToAdd) {
    while (daysToAdd > 0) {
        int daysInMonth = getDaysInMonth(presentDate.month, presentDate.year);
        int remainingDays = daysInMonth - presentDate.day + 1;

        if (remainingDays <= daysToAdd) {
            daysToAdd -= remainingDays;
            presentDate.day = 1;

            if (presentDate.month == 12) {
                presentDate.month = 1;
                presentDate.year++;
            } else {
                presentDate.month++;
            }
        } else {
            presentDate.day += daysToAdd;
            daysToAdd = 0;
        }
    }

    return presentDate;
}

int main() {
    struct Date presentDate, nextDate;
    int daysToAdd;

    printf("Enter present date (dd mm yyyy): ");
    scanf("%d %d %d", &presentDate.day, &presentDate.month, &presentDate.year);

    printf("Enter the number of days to add: ");
    scanf("%d", &daysToAdd);

    nextDate = nextdate(presentDate, daysToAdd);

    printf("Next date: %d %d %d\n", nextDate.day, nextDate.month, nextDate.year);

    return 0;
}
