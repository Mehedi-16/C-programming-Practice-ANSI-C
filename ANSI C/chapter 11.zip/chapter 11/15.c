#include <stdio.h>

struct student {
    char name[50];
    int age;
    float height;
};

int main() {
    struct student s;
    struct student *ptr = &s;
    printf("Enter student name: ");
    scanf("%[^\n]", ptr->name);

    printf("Enter student age: ");
    scanf("%d", &ptr->age);

    printf("Enter student height: ");
    scanf("%f", &ptr->height);
    printf("\nStudent Information:\n");
    printf("Name: %s\n", ptr->name);
    printf("Age: %d\n", ptr->age);
    printf("Height: %.2f\n", ptr->height);

    return 0;
}
