#include<stdio.h>
int main()
{
 int a,x;
 float b,c;
 printf("Enter number :");
 scanf("%d%f%f",&a,&b,&c);
 printf("x=a/(b-c)\n");
 x=a/(float)(b-c);
 printf("x is %d",x);
}