#include<stdio.h>
int main()
{
    int a,b,c;
    printf("Enter value (a,b,c) :");
    scanf("%d%d%d",&a,&b,&c);
    printf("%dx + %dy =%d",a,b,c);
}