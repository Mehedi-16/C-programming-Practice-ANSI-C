#include <stdio.h>

int binarySearch(int arr[], int size, int key) {
    int low = 0;
    int high = size - 1;

    while (low <= high) {
        int mid = (low + high) / 2;

        if (arr[mid] == key) {
            return mid;
        } else if (arr[mid] < key) {
            low = mid + 1; 
        } else {
            high = mid - 1;
        }
    }

    return -1;
}

int main() {
    int sortedList[] = {1, 3, 5, 7, 9, 11, 13, 15, 17, 19};
    int size = sizeof(sortedList) / sizeof(sortedList[0]);

    int key;
    printf("Enter the key value to search for: ");
    scanf("%d", &key);

    int index = binarySearch(sortedList, size, key);

    if (index != -1) {
        printf("Key found at index %d\n", index);
    } else {
        printf("Key not found\n");
    }

    return 0;
}
