#include <stdio.h>

#define MAX_ROWS 10 
int main() {
    int pascalTriangle[MAX_ROWS][MAX_ROWS];

    for (int i = 0; i < MAX_ROWS; i++) {
        pascalTriangle[i][0] = 1;
        pascalTriangle[i][i] = 1;
    }
    for (int i = 2; i < MAX_ROWS; i++) {
        for (int j = 1; j < i; j++) {
            pascalTriangle[i][j] = pascalTriangle[i - 1][j - 1] + pascalTriangle[i - 1][j];
        }
    }

    printf("Pascal's Triangle:\n");
    for (int i = 0; i < MAX_ROWS; i++) {
        for (int j = 0; j <= i; j++) {
            printf("%d ", pascalTriangle[i][j]);
        }
        printf("\n");
    }

    return 0;
}
