#include <stdio.h>

int main() {
    int cities = 1;
    int days = 5;

    int temperature[cities][days];

    printf("Enter the daily maximum temperatures for each city:\n");
    for (int i = 0; i < cities; i++) {
        printf("City %d:\n", i + 1);
        for (int j = 0; j < days; j++) {
            printf("Day %d: ", j + 1);
            scanf("%d", &temperature[i][j]);
        }
    }

    int highestTemp = temperature[0][0];
    int lowestTemp = temperature[0][0];
    int highestCity, highestDay, lowestCity, lowestDay;

    for (int i = 0; i < cities; i++) {
        for (int j = 0; j < days; j++) {
            if (temperature[i][j] > highestTemp) {
                highestTemp = temperature[i][j];
                highestCity = i;
                highestDay = j;
            }
            if (temperature[i][j] < lowestTemp) {
                lowestTemp = temperature[i][j];
                lowestCity = i;
                lowestDay = j;
            }
        }
    }

    printf("Highest Temperature: %d°C in City %d on Day %d\n", highestTemp, highestCity + 1, highestDay + 1);
    printf("Lowest Temperature: %d°C in City %d on Day %d\n", lowestTemp, lowestCity + 1, lowestDay + 1);

    return 0;
}
