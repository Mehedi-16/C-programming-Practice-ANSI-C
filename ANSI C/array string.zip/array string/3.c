#include <stdio.h>

int main() {
    int candidates = 5;
    int ballots;
    int count[candidates + 1];
    int spoiltBallots = 0;

    for (int i = 0; i <= candidates; i++) {
        count[i] = 0;
    }

    printf("Enter the number of ballots: ");
    scanf("%d", &ballots);

    for (int i = 0; i < ballots; i++) {
        int vote;
        printf("Enter vote for ballot %d: ", i + 1);
        scanf("%d", &vote);

        if (vote >= 1 && vote <= candidates) {
            count[vote]++;
        } else {
            spoiltBallots++;
        }
    }

    printf("\nVote Count:\n");
    for (int i = 1; i <= candidates; i++) {
        printf("Candidate %d: %d votes\n", i, count[i]);
    }
    printf("Spoilt Ballots: %d\n", spoiltBallots);

    return 0;
}
