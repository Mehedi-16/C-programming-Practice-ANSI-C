#include <stdio.h>

int main() {
    int n;
    printf("Enter the number of points: ");
    scanf("%d", &n);

    double x[n], y[n];
    printf("Enter the coordinates of the points (xi yi):\n");
    for (int i = 0; i < n; i++) {
        scanf("%lf %lf", &x[i], &y[i]);
    }

    double sum_x = 0, sum_y = 0, sum_xy = 0, sum_x_squared = 0;

    for (int i = 0; i < n; i++) {
        sum_x += x[i];
        sum_y += y[i];
        sum_xy += x[i] * y[i];
        sum_x_squared += x[i] * x[i];
    }

    double m = (n * sum_xy - sum_x * sum_y) / (n * sum_x_squared - sum_x * sum_x);
    double c = (sum_y - m * sum_x) / n;

    printf("Equation of the straight line: y = %.4lf * x + %.4lf\n", m, c);

    return 0;
}
