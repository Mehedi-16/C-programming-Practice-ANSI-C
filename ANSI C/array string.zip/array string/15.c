#include <stdio.h>

#define MAX_ROWS 10
#define MAX_COLS 10

int main() {
    int matrixA[MAX_ROWS][MAX_COLS], matrixB[MAX_ROWS][MAX_COLS];
    int resultSum[MAX_ROWS][MAX_COLS], resultDiff[MAX_ROWS][MAX_COLS];
    int m, n;

    printf("Enter the number of rows (m): ");
    scanf("%d", &m);

    printf("Enter the number of columns (n): ");
    scanf("%d", &n);

    printf("Enter the elements of matrix A:\n");
    for (int i = 0; i < m; i++)
        for (int j = 0; j < n; j++)
            scanf("%d", &matrixA[i][j]);

    printf("Enter the elements of matrix B:\n");
    for (int i = 0; i < m; i++)
        for (int j = 0; j < n; j++)
            scanf("%d", &matrixB[i][j]);

    for (int i = 0; i < m; i++)
        for (int j = 0; j < n; j++)
            resultSum[i][j] = matrixA[i][j] + matrixB[i][j];

    for (int i = 0; i < m; i++)
        for (int j = 0; j < n; j++)
            resultDiff[i][j] = matrixA[i][j] - matrixB[i][j];

    printf("\nMatrix A + B:\n");
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++)
            printf("%d ", resultSum[i][j]);
        printf("\n");
    }

    printf("\nMatrix A - B:\n");
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++)
            printf("%d ", resultDiff[i][j]);
        printf("\n");
    }

    return 0;
}
