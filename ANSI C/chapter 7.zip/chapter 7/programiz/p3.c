#include <stdio.h>

int main()
{
    char r;
    printf("Enter character: ");
    scanf("%c", &r);

    int num_rows = r - 'A' + 1;

    for (int i = 0; i < num_rows; ++i)
    {
        for (char c = 'A'; c <= 'A' + i; ++c)
        {
            printf("%c ", c);
        }
        printf("\n");
    }

    return 0;
}
