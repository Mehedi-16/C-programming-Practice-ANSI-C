#include <stdio.h>
int main() {
  int customer_code, calls_made;
  float bill_amount;

  printf("Enter customer code (0 to exit): ");
  scanf("%d", &customer_code);

  while (customer_code != 0) {
    printf("Enter number of calls made: ");
    scanf("%d", &calls_made);

    if (calls_made <= 100) {
      bill_amount = 250.0;
    } else {
      bill_amount = 250.0 + (calls_made - 100) * 1.25;
    }

    printf("Customer code: %d\n", customer_code);
    printf("Calls made: %d\n", calls_made);
    printf("Bill amount: Rs. %.2f\n", bill_amount);

    printf("Enter customer code (0 to exit): ");
    scanf("%d", &customer_code);
  }

  return 0;
}