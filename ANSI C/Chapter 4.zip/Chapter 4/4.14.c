#include <stdio.h>
#include <math.h>

#define PI 3.14159265

int main() {
    int angle;
    float radians, sine, cosine;

    printf("Angle\tSin\tCos\n");

    for (angle = 0; angle <= 180; angle += 15) {
        
        radians = angle * PI / 180;

        
        sine = sin(radians);
        cosine = cos(radians);

        
        printf("%d\t%.3f\t%.3f\n", angle, sine, cosine);
    }

    return 0;
}