#include <stdio.h>

int main() {
  float a, b, c, x;

  printf("Enter the values of a, b, and c: ");
  scanf("%f %f %f", &a, &b, &c);

  x = a - b/3 + c*2 - 1;

  printf("x = %4.2f\n", x);

}
