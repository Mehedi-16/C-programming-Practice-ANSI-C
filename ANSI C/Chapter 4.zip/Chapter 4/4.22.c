#include<stdio.h>
int main()
{
float a,b,c,d,x1,x2,x3;
printf("Enter Four Value: ");
scanf("%f%f%f%f",&a,&b,&c,&d);

x1=(a + b) * (c / d);
x2=(a + b) * c / d;
x3=(a + (b * c)/ d);

printf("x1= %f\n",x1);
printf("x2= %f\n",x2);
printf("x3= %f\n",x3);
}