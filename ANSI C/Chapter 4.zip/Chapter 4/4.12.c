#include <stdio.h>
int main() {
  int a, b, c;
  printf("Enter three values: ");
  scanf("%d %d %d", &a, &b, &c);
  int sum = a + b + c;
  printf("Sum: %d\n", sum);
  float average = (float) sum / 3;
  printf("Average: %.2f\n", average);
  int largest = a;
  if (b > largest) {
    largest = b;
  }
  if (c > largest) {
    largest = c;
  }
  printf("Largest: %d\n", largest);
  int smallest = a;
  if (b < smallest) {
    smallest = b;
  }
  if (c < smallest) {
    smallest = c;
  }
  printf("Smallest: %d\n", smallest);

  return 0;
}
