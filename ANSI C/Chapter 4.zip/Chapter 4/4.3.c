#include <stdio.h>
#include<math.h>

int main() {
    int num, temp, digits = 0;

    printf("Enter an integer: ");
    scanf("%d", &num);

   
    temp = num;
    while (temp != 0) {
        digits++;
        temp=temp /10;
    }

   
    printf("All digits: ");
    for (int i = digits; i >= 1; i--) {
        printf("%d ", num / (int) pow(10, i-1) % 10);
    }
    printf("\n");

    printf("All except first digit: ");
    for (int i = digits-1; i >= 1; i--) {
        printf("%d ", num / (int) pow(10, i-1) % 10);
    }
    printf("\n");

    printf("All except first two digits: ");
    for (int i = digits-2; i >= 1; i--) {
        printf("%d ", num / (int) pow(10, i-1) % 10);
    }
    printf("\n");

    printf("Last digit: %d\n", num % 10);
}