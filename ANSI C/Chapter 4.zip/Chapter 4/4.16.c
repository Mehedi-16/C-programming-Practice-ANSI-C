#include <stdio.h>
int main() {
  float meal_cost = 50.0;
  int sales_tax_rate = 8;
  float sales_tax_amount = meal_cost * (float)sales_tax_rate / 100.0;
  float total_cost = meal_cost + sales_tax_amount;
  printf("Meal cost: $%.2f\n", meal_cost);
  printf("Sales tax rate: %d%%\n", sales_tax_rate);
  printf("Sales tax amount: $%.2f\n", sales_tax_amount);
  printf("Total cost: $%.2f\n", total_cost);
  return 0;
}
