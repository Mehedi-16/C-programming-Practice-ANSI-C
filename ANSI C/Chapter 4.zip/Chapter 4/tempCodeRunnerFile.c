#include <stdio.h>
int main()
{
  int a=10,sum;
  float b=(4.0/6),c=(6/2);
  sum=a+b*c;
  printf("%d",sum);
}