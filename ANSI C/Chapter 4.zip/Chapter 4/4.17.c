#include <stdio.h>

int main()
 {
  unsigned int data = 0x7F;  
  unsigned int shifted_data = data << 2; 
  printf("Data: 0x%02X\n", data);
  printf("Shifted data: 0x%02X\n", shifted_data);
}
