#include <stdio.h>
#include <math.h>

int main() {
  int num;
  float sqrt_val, square_val;

  printf("Number\tSquare\tSquare Root\n");

  for (num = 0; num <= 100; num =num+10) 
  {
    square_val = pow(num, 2);
    sqrt_val = sqrt(num);
    printf("%d\t%.2f\t%.2f\n", num, square_val, sqrt_val);
  }

  return 0;
}
