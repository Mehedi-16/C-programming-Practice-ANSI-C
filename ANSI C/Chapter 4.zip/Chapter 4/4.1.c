#include <stdio.h>
#include <math.h>

int main() {
    float num;
    int integralPart;

    printf("Enter a floating-point number: ");
    scanf("%f", &num);

    integralPart = (int)floor(num);

    printf("The right-most digit of the integral part is %d\n", integralPart % 10);
}
