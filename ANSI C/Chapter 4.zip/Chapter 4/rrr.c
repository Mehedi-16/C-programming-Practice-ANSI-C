#include <stdio.h>

int main() {
  float a, b, c, d;
  float result1, result2, result3;

  printf("Enter the values of a, b, c, and d: ");
  scanf("%f %f %f %f", &a, &b, &c, &d);

  result1 = (a + b) * (c / d);
  result2 = (a + b) * c / d;
  result3 = a + (b * c) / d;

  printf("Result 1: %.2f\n", result1);
  printf("Result 2: %.2f\n", result2);
  printf("Result 3: %.2f\n", result3);

  return 0;
}
