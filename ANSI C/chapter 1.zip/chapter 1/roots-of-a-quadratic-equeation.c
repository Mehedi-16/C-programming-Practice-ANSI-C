#include <stdio.h>
#include <math.h>
int main()
{
    float a, b, c, x1, x2, D;
    printf("Enter the value (abc): ");
    scanf("%f%f%f", &a, &b, &c);
    D = ((b * b) - 4 * a * c);
    if (D > 0)
    {
        printf("Two real number\n");
    }
    else if (D = 0)
    {
        printf("One real solution\n");
    }
    else
    {
        printf("Complex Solutions\n");
    }
    x1 = (-b + sqrt(D)) / (2 * a);
    x2 = (-b - sqrt(D)) / (2 * a);
    printf("x1 is: %f\n", x1);
    printf("x2 is: %f\n", x2);
}