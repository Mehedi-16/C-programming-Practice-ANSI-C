#include <stdio.h>
int main()
{
    float pi = 3.1416, rad, Area;
    printf("Enter Radius Value: ");
    scanf("%f", &rad);
    Area = pi * rad * rad;
    printf("Area is: %.2f", Area);
}