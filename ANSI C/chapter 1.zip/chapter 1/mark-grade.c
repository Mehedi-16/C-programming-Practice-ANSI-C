#include<stdio.h>
int main()
{
int mark;
printf("Enter the mark: ");
scanf("%d",&mark);
if(mark>=90)
printf("Grade:O");
else if(mark>=80 && mark<90)
printf("Grade:E");
else if(mark>=70 && mark<90)
printf("Grade:A");
else if(mark>=60 && mark<70)
printf("Grade:B");
else if(mark>=50 && mark<60)
printf("Grade:C");
else if(mark>=40 && mark<50)
printf("Grade:D");
else
printf("Faill");
}