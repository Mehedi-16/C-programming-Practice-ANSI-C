#include<stdio.h>
int main()
{
int year=1,period;
float amount,inrate,value;
printf("Enter period,interest rate and amount: ");
scanf("%d%f%f",&period,&inrate,&amount);
while (year<=period)
{
value=amount+inrate*amount;
printf("year: %d value: %f\n",year,value);
year=year+1;
amount=value;
}
}