#include <stdio.h>
int main()
{
    int i,j,n1,n2,sum=0;
    printf("Enter the number: ");
    scanf("%d%d", &n1,&n2);
    printf("1*2+2*3+3*4+.....%d*%d\n",n1,n2);
for ( i = 1;i<=n1; i++)
{
    for (j=2; j<=n2;j++)
sum=sum+(i*j);
}
printf("sum is: %d",sum);
}