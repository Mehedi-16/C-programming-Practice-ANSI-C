
   #include <stdio.h>
  int main()
   {
    int i, j,n;
    printf("The prime numbers between 1 and 199 are:\n");
    for (i =1; i <=200; i++) 
    {
       for ( j = 2; j<=i; j++)
       {
        if (i%j==0)
        break;   
       }
   if(i==j)    
   printf("%d\n",j);

    }
  }
