#include<stdio.h>
int main()
{
int year;
printf("Enteer year: ");
scanf("%d",&year);
if ( year%400==0 )
{
printf("Leap year");
}
else if (year%100!=0 && year%4==0)
{
    printf("Leap year");
}
else
{
    printf("Not leap year");
}
}