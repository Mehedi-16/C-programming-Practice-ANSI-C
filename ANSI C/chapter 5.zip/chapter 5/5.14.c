#include<stdio.h>
int main()
{
int n, j;
for (n = 5; n >= 1; n--) 
{
     for (j = n; j >= 1; j-- ) 
     {
     printf("%d", j);
     }
     printf("\n");
}
}