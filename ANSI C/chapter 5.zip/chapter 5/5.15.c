#include <stdio.h>
#include <math.h>

int main()
{
    float investment, rate, time, CI;

    printf("Enter Investment (amount): ");
    scanf("%f", &investment);

    printf("Enter time: ");
    scanf("%f", &time);

    printf("Enter inrate: ");
    scanf("%f", &rate);
    CI = investment* (pow((1 + rate / 100), time));
    printf("Compound Interest = %f", CI);
}