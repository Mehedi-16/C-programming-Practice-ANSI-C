#include <stdio.h>
int main()
{
  char text1[] = "WORD", text2[] = "PROCESSING",text3[] = "W.P.";
  printf("%s %s\n",text1,text2);
  printf("%s\n%s\n",text1,text2);
  printf("%s\n",text3);
}